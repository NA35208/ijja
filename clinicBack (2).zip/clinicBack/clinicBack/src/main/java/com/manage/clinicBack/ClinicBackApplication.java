package com.manage.clinicBack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClinicBackApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClinicBackApplication.class, args);
	}

}
