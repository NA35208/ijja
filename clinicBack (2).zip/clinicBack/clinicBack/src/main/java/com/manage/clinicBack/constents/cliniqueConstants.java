package com.manage.clinicBack.constents;

public class cliniqueConstants {
    public static final String SOMETHING_WENT_WRONG = "Erreur.";
    public static final String INVALID_DATA="Données non valid";

    public static final String UNAUTHORIZED_ACCESS="cette acées n'est pas autoriser";

}