package com.manage.clinicBack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClinicBackApplicationTests {

	@Test
	void contextLoads() {
	}

}
